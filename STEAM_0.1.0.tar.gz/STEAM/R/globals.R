utils::globalVariables(c("bin","cM","chr","corr_11","corr_12","corr_13","corr_21","corr_22",
                         "corr_23","corr_31","corr_32","corr_33","pair"
                         ,"snp1","snp2","theta","N"))


