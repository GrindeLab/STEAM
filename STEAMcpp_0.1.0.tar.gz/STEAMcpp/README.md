# STEAMcpp

Significance Threshold Estimation for Admixture Mapping using Rcpp (R Package)

This is a working version of STEAM (Significance Threshold Estimation for Admixture Mapping) with core functions implemented with Rcpp. We are writing some vignettes, packing the package and planning to publish it.

See functionality of the STEAM package: https://github.com/kegrinde/STEAM.
